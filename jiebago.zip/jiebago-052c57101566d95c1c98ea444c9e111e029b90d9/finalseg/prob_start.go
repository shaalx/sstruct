package finalseg

var ProbStart = make(map[byte]float64)

func init() {
	ProbStart['B'] = -0.26268660809250016
	ProbStart['E'] = -3.14e+100
	ProbStart['M'] = -3.14e+100
	ProbStart['S'] = -1.4652633398537678
}
